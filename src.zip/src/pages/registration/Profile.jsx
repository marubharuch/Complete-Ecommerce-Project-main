import React from 'react'
import Layout from '../../components/layout/Layout'

function Profile() {
  return (
    <Layout>
        <div>Profile</div>
        </Layout>
    
  )
}

export default Profile