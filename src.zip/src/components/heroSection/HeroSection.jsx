import React from 'react'

function HeroSection() {
  return (
    <div>
       { //<!--img src="https://static.vecteezy.com/system/resources/previews/004/299/835/original/online-shopping-on-phone-buy-sell-business-digital-web-banner-application-money-advertising-payment-ecommerce-illustration-search-free-vector.jpg" alt="" /--!>
}       <img src=' https://gumlet.assettype.com/knocksense%2Fimport%2F27935626%2Forigin.jpg?auto=format%2Ccompress&fit=max&format=webp&w=1366&dpr=1.0'/>
    
    
    </div>
  )
}

export default HeroSection